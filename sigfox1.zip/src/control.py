import requests
import time



def setup(args):
    """Detup function - runs when the plugin is created or edited"""
    pass
    


